<?php

namespace MgRTC\Turn;

/**
 * TurnInterface defines a contract every TURN adapter needs to comply
 *
 * @author magnoliyan
 */
interface TurnInterface
{
    /**
     * Generate TURN URIs with credentials, array of array [[urls=>[],username=>'',credential=>'']]
     * 
     * @return array
     */
    public function getTURNServers();
}
