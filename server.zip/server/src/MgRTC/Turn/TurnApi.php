<?php

namespace MgRTC\Turn;

/**
 * Implementation of the https://tools.ietf.org/html/draft-uberti-behave-turn-rest-00
 *
 * @author magnoliyan
 */
class TurnApi implements TurnInterface
{
    protected $config = [];
    
    public function __construct(array $config)
    {
        $this->config = $config;
    }
    
    /**
     * Generate TURN URIs with credentials
     * 
     * @return array
     */
    public function getTURNServers()
    {
        if(!isset($this->config['secret']) || !isset($this->config['username'])){
            return [];
        }
        $ts = time() + $this->config['ttl'];
        $username = $ts . ':' . $this->config['username'];
        $password = base64_encode(hash_hmac('sha1', $username, $this->config['secret'], true));        
        
        return [
            [
                'username'      => $username,
                'credential'    => $password,
                'urls'          => $this->config['uris'],
            ],
        ];
    }
}
