<?php


/**
 * Description of FacebookCli
 *
 * @author milan
 */

namespace MgRTC\Session\Facebook;

class FacebookCli extends \BaseFacebook {

    protected function setPersistentData($key, $value) {

    }

    protected function getPersistentData($key, $default = false) {
        return $default;
    }

    protected function clearPersistentData($key) {

    }

    protected function clearAllPersistentData() {

    }

}
